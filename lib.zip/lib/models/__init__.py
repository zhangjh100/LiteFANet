# -*- encoding: utf-8 -*-
import torch.optim as optim
from monai.networks.nets import AttentionUnet
from monai.networks.nets import UNETR, SwinUNETR

import lib.utils as utils
from lib.models.UXNet_3D.network_backbone import UXNET
from lib.models.nnFormer.nnFormer_seg import nnFormer
from .AttU_Net import AttU_Net
from .AttentionUNet3D import AttentionUNet3D
from .BCDUNet import BCDUNet
from .BiSeNetV2 import BiSeNetV2
from .CANet import Comprehensive_Atten_Unet
from .CENet import CE_Net
from .CKDNet import DeepLab_Aux
from .CPFNet import CPF_Net
from .DANet import DANet
from .DATransUNet import DATransUNet
from .DenseASPPUNet import DenseASPPUNet
from .DenseVNet import DenseVNet
from .DenseVoxelNet import DenseVoxelNet
from .HighResNet3D import HighResNet3D
from .MedT import MedT
from .MobileNetV2 import MobileNetV2
from .MsRED import Ms_red_v1, Ms_red_v2
from .MultiResUNet3D import MultiResUNet3D
from .LiteFANet import LiteFANet
from .PSPNet import PSPNet
from .R2AttentionUNet import R2AttentionU_Net
from .R2UNet import R2U_Net
from .SegFormer import SegFormer
from .SwinUnet import SwinUnet
from .TransBTS import BTS
from .TransUNet import CONFIGS as CONFIGS_ViT_seg
from .TransUNet import TransUNet
from .UNet import UNet
from .UNet3D import UNet3D
from .VNet import VNet


def get_model_optimizer_lr_scheduler(opt):
    # initialize model
    if opt["dataset_name"] == "3D-CBCT-Tooth" or opt["dataset_name"] == "Kfold-3D-CBCT-Tooth":
        if opt["model_name"] == "DenseVNet":
            model = DenseVNet(in_channels=opt["in_channels"], classes=opt["classes"])

        elif opt["model_name"] == "UNet3D":
            model = UNet3D(in_channels=opt["in_channels"], out_channels=opt["classes"], is_segmentation=False)

        elif opt["model_name"] == "VNet":
            model = VNet(in_channels=opt["in_channels"], classes=opt["classes"])

        elif opt["model_name"] == "AttentionUNet3D":
            # model = AttentionUNet3D(in_channels=opt["in_channels"], out_channels=opt["classes"])
            model = AttentionUnet(spatial_dims=3, in_channels=opt["in_channels"], out_channels=opt["classes"], channels=(64, 128, 256, 512, 1024), strides=(2, 2, 2, 2))

        elif opt["model_name"] == "R2UNet":
            model = R2U_Net(in_channels=opt["in_channels"], out_channels=opt["classes"])

        elif opt["model_name"] == "R2AttentionUNet":
            model = R2AttentionU_Net(in_channels=opt["in_channels"], out_channels=opt["classes"])

        elif opt["model_name"] == "HighResNet3D":
            model = HighResNet3D(in_channels=opt["in_channels"], classes=opt["classes"])

        elif opt["model_name"] == "DenseVoxelNet":
            model = DenseVoxelNet(in_channels=opt["in_channels"], classes=opt["classes"])

        elif opt["model_name"] == "MultiResUNet3D":
            model = MultiResUNet3D(in_channels=opt["in_channels"], classes=opt["classes"])

        elif opt["model_name"] == "DenseASPPUNet":
            model = DenseASPPUNet(in_channels=opt["in_channels"], classes=opt["classes"])

        elif opt["model_name"] == "UNETR":
            model = UNETR(
                in_channels=opt["in_channels"],
                out_channels=opt["classes"],
                img_size=(160, 160, 96),
                feature_size=16,
                hidden_size=768,
                mlp_dim=3072,
                num_heads=12,
                pos_embed="perceptron",
                norm_name="instance",
                res_block=True,
                dropout_rate=0.0,
            )

        elif opt["model_name"] == "SwinUNETR":
            model = SwinUNETR(
                img_size=(160, 160, 96),
                in_channels=opt["in_channels"],
                out_channels=opt["classes"],
                feature_size=48,
                use_checkpoint=False,
            )

        elif opt["model_name"] == "TransBTS":
            model = BTS(img_dim=(160, 160, 96), patch_dim=8, num_channels=opt["in_channels"], num_classes=opt["classes"],
                        embedding_dim=512,
                        num_heads=8,
                        num_layers=4,
                        hidden_dim=4096,
                        dropout_rate=0.1,
                        attn_dropout_rate=0.1,
                        conv_patch_representation=True,
                        positional_encoding_type="learned",
                        )

        elif opt["model_name"] == "nnFormer":
            model = nnFormer(crop_size=(160, 160, 96), input_channels=opt["in_channels"], num_classes=opt["classes"])

        elif opt["model_name"] == "3DUXNet":
            model = UXNET(
                in_chans=opt["in_channels"],
                out_chans=opt["classes"],
                depths=[2, 2, 2, 2],
                feat_size=[48, 96, 192, 384],
                drop_path_rate=0,
                layer_scale_init_value=1e-6,
                spatial_dims=3,
            )

        elif opt["model_name"] == "LiteFANet":
            model = LiteFANet(in_channels=opt["in_channels"], out_channels=opt["classes"], dim=opt["dimension"], scaling_version=opt["scaling_version"])

        else:
            raise RuntimeError(f"No {opt['model_name']} model available on {opt['dataset_name']} dataset")

    elif opt["dataset_name"] == "MMOTU" or opt["dataset_name"] == "MMOTU-Kvasir-SEG" or opt["dataset_name"] == "MMOTU-ISIC-2018":
        if opt["model_name"] == "LiteFANet":
            model = LiteFANet(in_channels=opt["in_channels"], out_channels=opt["classes"], dim=opt["dimension"], scaling_version=opt["scaling_version"])

        elif opt["model_name"] == "MobileNetV2":
            model = MobileNetV2(in_channels=opt["in_channels"], out_channels=opt["classes"], input_size=opt["resize_shape"][0], width_mult=1.)

        elif opt["model_name"] == "PSPNet":
            model = PSPNet(n_classes=opt["classes"], backend='resnet50', pretrained=True)

        elif opt["model_name"] == "DANet":
            model = DANet(nclass=opt["classes"])

        elif opt["model_name"] == "SegFormer":
            model = SegFormer(channels=opt["in_channels"], num_classes=opt["classes"])

        elif opt["model_name"] == "UNet":
            model = UNet(n_channels=opt["in_channels"], n_classes=opt["classes"])

        elif opt["model_name"] == "TransUNet":
            config_vit = CONFIGS_ViT_seg["R50-ViT-B_16"]
            config_vit.n_classes = opt["classes"]
            config_vit.n_skip = 3
            config_vit.patches.grid = (int(opt["resize_shape"][0] / 16), int(opt["resize_shape"][1] / 16))
            model = TransUNet(config_vit, img_size=opt["resize_shape"][0], num_classes=config_vit.n_classes)

        elif opt["model_name"] == "BiSeNetV2":
            model = BiSeNetV2(n_classes=opt["classes"])

        elif opt["model_name"] == "MedT":
            model = MedT(imgchan=opt["in_channels"], num_classes=opt["classes"])
        elif opt["model_name"] == "CKDNet":
            model = DeepLab_Aux(num_classes=opt["classes"])
        elif opt["model_name"] == "CENet":
            model = CE_Net(classes=opt["classes"], channels=opt["in_channels"])

        elif opt["model_name"] == "CPFNet":
            model = CPF_Net(classes=opt["classes"], channels=opt["in_channels"])

        else:
            raise RuntimeError(f"No {opt['model_name']} model available on {opt['dataset_name']} dataset")

    elif opt["dataset_name"] == "ISIC-2018" or opt["dataset_name"] == "DRIVE" or opt["dataset_name"] == "STARE" or opt["dataset_name"] == "CHASE-DB1" or opt["dataset_name"] == "Kvasir-SEG":
        if opt["model_name"] == "LiteFANet":
            model = LiteFANet(in_channels=opt["in_channels"], out_channels=opt["classes"], dim=opt["dimension"], scaling_version=opt["scaling_version"])

        elif opt["model_name"] == "MobileNetV2":
            model = MobileNetV2(in_channels=opt["in_channels"], out_channels=opt["classes"], input_size=opt["resize_shape"][0], width_mult=1.)

        elif opt["model_name"] == "UNet":
            model = UNet(n_channels=opt["in_channels"], n_classes=opt["classes"])

        elif opt["model_name"] == "MsRED":
            model = Ms_red_v2(classes=opt["classes"], channels=opt["in_channels"], out_size=opt["resize_shape"])

        elif opt["model_name"] == "CKDNet":
            model = DeepLab_Aux(num_classes=opt["classes"])

        elif opt["model_name"] == "BCDUNet":
            model = BCDUNet(output_dim=opt["classes"], input_dim=opt["in_channels"], frame_size=opt["resize_shape"])

        elif opt["model_name"] == "CANet":
            model = Comprehensive_Atten_Unet(in_ch=opt["in_channels"], n_classes=opt["classes"], out_size=opt["resize_shape"])

        elif opt["model_name"] == "CENet":
            model = CE_Net(classes=opt["classes"], channels=opt["in_channels"])

        elif opt["model_name"] == "CPFNet":
            model = CPF_Net(classes=opt["classes"], channels=opt["in_channels"])

        elif opt["model_name"] == "AttU_Net":
            model = AttU_Net(img_ch=opt["in_channels"], output_ch=opt["classes"])

        elif opt["model_name"] == "SwinUnet":
            model = SwinUnet(img_size=opt["resize_shape"][0], num_classes=opt["classes"])

        elif opt["model_name"] == "DATransUNet":
            model = DATransUNet(img_size=opt["resize_shape"][0], num_classes=opt["classes"])

        else:
            raise RuntimeError(f"No {opt['model_name']} model available on {opt['dataset_name']} dataset")

    else:
        raise RuntimeError(f"No {opt['dataset_name']} dataset available when initialize model")

    # initialize model and weights
    model = model.to(opt["device"])
    utils.init_weights(model, init_type="kaiming")

    # initialize optimizer
    if opt["optimizer_name"] == "SGD":
        optimizer = optim.SGD(model.parameters(), lr=opt["learning_rate"], momentum=opt["momentum"],
                              weight_decay=opt["weight_decay"])

    elif opt["optimizer_name"] == 'Adagrad':
        optimizer = optim.Adagrad(model.parameters(), lr=opt["learning_rate"], weight_decay=opt["weight_decay"])

    elif opt["optimizer_name"] == "RMSprop":
        optimizer = optim.RMSprop(model.parameters(), lr=opt["learning_rate"], weight_decay=opt["weight_decay"],
                                  momentum=opt["momentum"])

    elif opt["optimizer_name"] == "Adam":
        optimizer = optim.Adam(model.parameters(), lr=opt["learning_rate"], weight_decay=opt["weight_decay"])

    elif opt["optimizer_name"] == "AdamW":
        optimizer = optim.AdamW(model.parameters(), lr=opt["learning_rate"], weight_decay=opt["weight_decay"])

    elif opt["optimizer_name"] == "Adamax":
        optimizer = optim.Adamax(model.parameters(), lr=opt["learning_rate"], weight_decay=opt["weight_decay"])

    elif opt["optimizer_name"] == "Adadelta":
        optimizer = optim.Adadelta(model.parameters(), lr=opt["learning_rate"], weight_decay=opt["weight_decay"])

    else:
        raise RuntimeError(f"No {opt['optimizer_name']} optimizer available")

    # initialize lr_scheduler
    if opt["lr_scheduler_name"] == "ExponentialLR":
        lr_scheduler = optim.lr_scheduler.ExponentialLR(optimizer, gamma=opt["gamma"])

    elif opt["lr_scheduler_name"] == "StepLR":
        lr_scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=opt["step_size"], gamma=opt["gamma"])

    elif opt["lr_scheduler_name"] == "MultiStepLR":
        lr_scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=opt["milestones"], gamma=opt["gamma"])

    elif opt["lr_scheduler_name"] == "CosineAnnealingLR":
        lr_scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=opt["T_max"])

    elif opt["lr_scheduler_name"] == "CosineAnnealingWarmRestarts":
        lr_scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer, T_0=opt["T_0"],
                                                                      T_mult=opt["T_mult"])

    elif opt["lr_scheduler_name"] == "OneCycleLR":
        lr_scheduler = optim.lr_scheduler.OneCycleLR(optimizer, max_lr=opt["learning_rate"],
                                                     steps_per_epoch=opt["steps_per_epoch"], epochs=opt["end_epoch"], cycle_momentum=False)

    elif opt["lr_scheduler_name"] == "ReduceLROnPlateau":
        lr_scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode=opt["mode"], factor=opt["factor"],
                                                            patience=opt["patience"])
    else:
        raise RuntimeError(f"No {opt['lr_scheduler_name']} lr_scheduler available")

    return model, optimizer, lr_scheduler


def get_model(opt):
    # initialize model
    if opt["dataset_name"] == "3D-CBCT-Tooth" or opt["dataset_name"] == "Kfold-3D-CBCT-Tooth":
        if opt["model_name"] == "DenseVNet":
            model = DenseVNet(in_channels=opt["in_channels"], classes=opt["classes"])

        elif opt["model_name"] == "UNet3D":
            model = UNet3D(in_channels=opt["in_channels"], out_channels=opt["classes"], is_segmentation=False)

        elif opt["model_name"] == "VNet":
            model = VNet(in_channels=opt["in_channels"], classes=opt["classes"])

        elif opt["model_name"] == "AttentionUNet3D":
            # model = AttentionUNet3D(in_channels=opt["in_channels"], out_channels=opt["classes"])
            model = AttentionUnet(spatial_dims=3, in_channels=opt["in_channels"], out_channels=opt["classes"], channels=(64, 128, 256, 512, 1024), strides=(2, 2, 2, 2))

        elif opt["model_name"] == "R2UNet":
            model = R2U_Net(in_channels=opt["in_channels"], out_channels=opt["classes"])

        elif opt["model_name"] == "R2AttentionUNet":
            model = R2AttentionU_Net(in_channels=opt["in_channels"], out_channels=opt["classes"])

        elif opt["model_name"] == "HighResNet3D":
            model = HighResNet3D(in_channels=opt["in_channels"], classes=opt["classes"])

        elif opt["model_name"] == "DenseVoxelNet":
            model = DenseVoxelNet(in_channels=opt["in_channels"], classes=opt["classes"])

        elif opt["model_name"] == "MultiResUNet3D":
            model = MultiResUNet3D(in_channels=opt["in_channels"], classes=opt["classes"])

        elif opt["model_name"] == "DenseASPPUNet":
            model = DenseASPPUNet(in_channels=opt["in_channels"], classes=opt["classes"])

        elif opt["model_name"] == "UNETR":
            model = UNETR(
                in_channels=opt["in_channels"],
                out_channels=opt["classes"],
                img_size=(160, 160, 96),
                feature_size=16,
                hidden_size=768,
                mlp_dim=3072,
                num_heads=12,
                pos_embed="perceptron",
                norm_name="instance",
                res_block=True,
                dropout_rate=0.0,
            )

        elif opt["model_name"] == "SwinUNETR":
            model = SwinUNETR(
                img_size=(160, 160, 96),
                in_channels=opt["in_channels"],
                out_channels=opt["classes"],
                feature_size=48,
                use_checkpoint=False,
            )

        elif opt["model_name"] == "TransBTS":
            model = BTS(img_dim=(160, 160, 96), patch_dim=8, num_channels=opt["in_channels"], num_classes=opt["classes"],
                        embedding_dim=512,
                        num_heads=8,
                        num_layers=4,
                        hidden_dim=4096,
                        dropout_rate=0.1,
                        attn_dropout_rate=0.1,
                        conv_patch_representation=True,
                        positional_encoding_type="learned",
                        )

        elif opt["model_name"] == "nnFormer":
            model = nnFormer(crop_size=(160, 160, 96), input_channels=opt["in_channels"], num_classes=opt["classes"])

        elif opt["model_name"] == "3DUXNet":
            model = UXNET(
                in_chans=opt["in_channels"],
                out_chans=opt["classes"],
                depths=[2, 2, 2, 2],
                feat_size=[48, 96, 192, 384],
                drop_path_rate=0,
                layer_scale_init_value=1e-6,
                spatial_dims=3,
            )

        elif opt["model_name"] == "LiteFANet":
            model = LiteFANet(in_channels=opt["in_channels"], out_channels=opt["classes"], dim=opt["dimension"], scaling_version=opt["scaling_version"])

        else:
            raise RuntimeError(f"No {opt['model_name']} model available on {opt['dataset_name']} dataset")

    elif opt["dataset_name"] == "MMOTU" or opt["dataset_name"] == "MMOTU-ISIC-2018" or opt["dataset_name"] == "MMOTU-Kvasir-SEG" :
        if opt["model_name"] == "LiteFANet":
            model = LiteFANet(in_channels=opt["in_channels"], out_channels=opt["classes"], dim=opt["dimension"], scaling_version=opt["scaling_version"])

        elif opt["model_name"] == "MobileNetV2":
            model = MobileNetV2(in_channels=opt["in_channels"], out_channels=opt["classes"], input_size=opt["resize_shape"][0], width_mult=1.)

        elif opt["model_name"] == "PSPNet":
            model = PSPNet(n_classes=opt["classes"], backend='resnet50', pretrained=True)

        elif opt["model_name"] == "DANet":
            model = DANet(nclass=opt["classes"])

        elif opt["model_name"] == "SegFormer":
            model = SegFormer(channels=opt["in_channels"], num_classes=opt["classes"])

        elif opt["model_name"] == "UNet":
            model = UNet(n_channels=opt["in_channels"], n_classes=opt["classes"])

        elif opt["model_name"] == "TransUNet":
            config_vit = CONFIGS_ViT_seg["R50-ViT-B_16"]
            config_vit.n_classes = opt["classes"]
            config_vit.n_skip = 3
            config_vit.patches.grid = (int(opt["resize_shape"][0] / 16), int(opt["resize_shape"][1] / 16))
            model = TransUNet(config_vit, img_size=opt["resize_shape"][0], num_classes=config_vit.n_classes)

        elif opt["model_name"] == "BiSeNetV2":
            model = BiSeNetV2(n_classes=opt["classes"])

        elif opt["model_name"] == "MedT":
            model = MedT(imgchan=opt["in_channels"], num_classes=opt["classes"])

        elif opt["model_name"] == "CKDNet":
            model = DeepLab_Aux(num_classes=opt["classes"])
        elif opt["model_name"] == "CENet":
            model = CE_Net(classes=opt["classes"], channels=opt["in_channels"])

        elif opt["model_name"] == "CPFNet":
            model = CPF_Net(classes=opt["classes"], channels=opt["in_channels"])


        else:
            raise RuntimeError(f"No {opt['model_name']} model available on {opt['dataset_name']} dataset")

    elif opt["dataset_name"] == "ISIC-2018" or opt["dataset_name"] == "DRIVE" or opt["dataset_name"] == "STARE" or opt["dataset_name"] == "CHASE-DB1" or opt["dataset_name"] == "Kvasir-SEG":
        if opt["model_name"] == "LiteFANet":
            model = LiteFANet(in_channels=opt["in_channels"], out_channels=opt["classes"], dim=opt["dimension"], scaling_version=opt["scaling_version"])

        elif opt["model_name"] == "MobileNetV2":
            model = MobileNetV2(in_channels=opt["in_channels"], out_channels=opt["classes"], input_size=opt["resize_shape"][0], width_mult=1.)

        elif opt["model_name"] == "UNet":
            model = UNet(n_channels=opt["in_channels"], n_classes=opt["classes"])

        elif opt["model_name"] == "MsRED":
            model = Ms_red_v2(classes=opt["classes"], channels=opt["in_channels"], out_size=opt["resize_shape"])

        elif opt["model_name"] == "CKDNet":
            model = DeepLab_Aux(num_classes=opt["classes"])

        elif opt["model_name"] == "BCDUNet":
            model = BCDUNet(output_dim=opt["classes"], input_dim=opt["in_channels"], frame_size=opt["resize_shape"])

        elif opt["model_name"] == "CANet":
            model = Comprehensive_Atten_Unet(in_ch=opt["in_channels"], n_classes=opt["classes"], out_size=opt["resize_shape"])

        elif opt["model_name"] == "CENet":
            model = CE_Net(classes=opt["classes"], channels=opt["in_channels"])

        elif opt["model_name"] == "CPFNet":
            model = CPF_Net(classes=opt["classes"], channels=opt["in_channels"])

        elif opt["model_name"] == "AttU_Net":
            model = AttU_Net(img_ch=opt["in_channels"], output_ch=opt["classes"])

        elif opt["model_name"] == "SwinUnet":
            model = SwinUnet(img_size=opt["resize_shape"][0], num_classes=opt["classes"])

        elif opt["model_name"] == "DATransUNet":
            model = DATransUNet(img_size=opt["resize_shape"][0], num_classes=opt["classes"])
        elif opt["model_name"] == "TransUNet":
            config_vit = CONFIGS_ViT_seg["R50-ViT-B_16"]
            config_vit.n_classes = opt["classes"]
            config_vit.n_skip = 3
            config_vit.patches.grid = (int(opt["resize_shape"][0] / 16), int(opt["resize_shape"][1] / 16))
            model = TransUNet(config_vit, img_size=opt["resize_shape"][0], num_classes=config_vit.n_classes)
        elif opt["model_name"] == "DANet":
            model = DANet(nclass=opt["classes"])
        else:
            raise RuntimeError(f"No {opt['model_name']} model available on {opt['dataset_name']} dataset")

    else:
        raise RuntimeError(f"No {opt['dataset_name']} dataset available when initialize model")

    model = model.to(opt["device"])

    return model
